package com.msaggik.tenthlessoncalculator;

@FunctionalInterface
public interface Calculation {

    float calculate(float x, float y);

}
